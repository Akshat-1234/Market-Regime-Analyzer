import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { BacktestProvider } from "./context/BacktestContext.jsx";
import "./styles/global.css";
import "./styles/layout.css";
import "./styles/components.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <BacktestProvider>
        <App />
      </BacktestProvider>
    </BrowserRouter>
  </React.StrictMode>
);
