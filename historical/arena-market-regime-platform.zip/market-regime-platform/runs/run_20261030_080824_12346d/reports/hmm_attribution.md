# HMM incremental-value attribution

Run: `run_20261030_080824_12346d` · source data: 2007-09-17–2026-10-22 · OOS returns: 2012-01-05–2026-10-22 · 10 bps one-way · cash 6.5% · extra execution delay 1 session(s).

Real HMM + Trend Sharpe 0.287 vs Trend 0.286; maximum drawdown 17.2% vs 20.9%. These are descriptive estimates, not proof of a true improvement.

## Controls

| control | n_simulations | cagr | sharpe | sharpe_p05 | sharpe_p95 | max_drawdown | mean_exposure | turnover_per_year | fraction_real_sharpe_above_control |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Trend alone | 1 | 0.0926 | 0.2859 | 0.2859 | 0.2859 | 0.2093 | 0.6836 | 12.8988 | — |
| Trend + real HMM | 1 | 0.0912 | 0.2873 | 0.2873 | 0.2873 | 0.1720 | 0.7187 | 7.3528 | — |
| Trend + Past-only shuffled | 200 | 0.0837 | 0.2203 | 0.1874 | 0.2618 | 0.1914 | 0.6923 | 19.0219 | 0.9950 |
| Trend + Past-only block shuffled | 200 | 0.0962 | 0.3316 | 0.2921 | 0.3666 | 0.1891 | 0.6922 | 7.7458 | 0.0250 |
| Trend + Exposure/turnover-matched random | 200 | 0.0966 | 0.3342 | 0.2976 | 0.3721 | 0.1885 | 0.6927 | 7.2885 | 0.0200 |

Control p05/p95 are empirical simulation quantiles, **not** confidence intervals on market performance or p-values. The fraction real exceeds control is a descriptive fraction, not a formal significance test.

All controls only sample HMM exposures already observed before each control decision. The first point initializes from the current real HMM; subsequent shuffled draws are prior-only resampling with replacement, block draws copy already completed historical blocks, and the matched random control uses a past-only redraw/hold rule. Therefore the distributions match only approximately. Exposure KS, percentiles and turnover differences are recorded per simulation. Shuffled paths can have substantially greater turnover; results include actual costs and a separately labelled approximate common-fee-schedule Sharpe diagnostic. The latter is a counterfactual, not a tradable backtest.

## Paired bootstrap vs trend and the mean of simulated controls

| control | observed_sharpe_difference | lower | upper | fraction_le_zero |
| --- | --- | --- | --- | --- |
| Trend | 0.0014 | -0.1887 | 0.1774 | 0.5090 |
| Mean control: Past-only shuffled | 0.0638 | -0.0086 | 0.1440 | 0.0470 |
| Mean control: Past-only block shuffled | -0.0445 | -0.1185 | 0.0360 | 0.8800 |
| Mean control: Exposure/turnover-matched random | -0.0490 | -0.1241 | 0.0353 | 0.8950 |

Each control reference here is the daily equal-weight mean return across its simulations; it is not a confidence interval against a single random control. Bootstrap fractions are not p-values. Intervals spanning zero do not prove equivalence. Block bootstrap assumes local stationarity and does not correct for the previous search across many configurations. Economic magnitude must be interpreted alongside turnover, exposure and costs.

## Market-period comparison

| period | control | real_sharpe | trend_sharpe | control_sharpe_median | fraction_real_above_control |
| --- | --- | --- | --- | --- | --- |
| 2013 | Past-only shuffled | -0.3772 | -0.4533 | -0.2482 | 0.0000 |
| 2013 | Past-only block shuffled | -0.3772 | -0.4533 | -0.2087 | 0.0000 |
| 2013 | Exposure/turnover-matched random | -0.3772 | -0.4533 | -0.2074 | 0.0000 |
| 2015–2016 | Past-only shuffled | -0.3956 | -0.1901 | -0.4019 | 0.5900 |
| 2015–2016 | Past-only block shuffled | -0.3956 | -0.1901 | -0.3138 | 0.0350 |
| 2015–2016 | Exposure/turnover-matched random | -0.3956 | -0.1901 | -0.3096 | 0.0300 |
| 2020 COVID + recovery | Past-only shuffled | 1.2809 | 1.8631 | 0.9902 | 0.9850 |
| 2020 COVID + recovery | Past-only block shuffled | 1.2809 | 1.8631 | 1.0637 | 0.9150 |
| 2020 COVID + recovery | Exposure/turnover-matched random | 1.2809 | 1.8631 | 1.0493 | 0.9200 |
| 2022 | Past-only shuffled | -0.5739 | -0.9353 | -0.6545 | 0.7750 |
| 2022 | Past-only block shuffled | -0.5739 | -0.9353 | -0.5100 | 0.3050 |
| 2022 | Exposure/turnover-matched random | -0.5739 | -0.9353 | -0.5121 | 0.2300 |

Short stress windows have noisy annualized ratios. [Simulation CSV](../attribution_simulations.csv) · [Distribution chart](../figures/attribution_sharpe.png).
