# Data quality and features

Run: `run_20261030_080824_12346d` · source data: 2007-09-17–2026-10-22 · OOS returns: 2012-01-05–2026-10-22 · 10 bps one-way · cash 6.5% · extra execution delay 1 session(s).

Duplicate dates: 0; invalid OHLC relationships: 0; absolute close-return >5%: 43 sessions; zero-return days: 4. Weekdays lacking a row: 301; these include exchange holidays and are not certified missing trading sessions.

The small 2007–2010 overnight gaps and high return correlation warrant vendor verification, not automatic deletion. The default HMM uses Close-derived features only. The 16-feature PCA and correlation diagnostics are fitted on observations before the first OOS signal, and are not used to tune the default model.

| year | observations | overnight_gap_vol_daily | intraday_vol_daily | close_intraday_return_correlation | near_previous_close_within_1bp |
| --- | --- | --- | --- | --- | --- |
| 2007 | 72 | 0.0014 | 0.0195 | 0.9973 | 0.2083 |
| 2008 | 245 | 0.0045 | 0.0274 | 0.9871 | 0.1959 |
| 2009 | 241 | 0.0021 | 0.0217 | 0.9955 | 0.3693 |
| 2010 | 250 | 0.0024 | 0.0101 | 0.9729 | 0.3400 |
| 2011 | 242 | 0.0079 | 0.0114 | 0.8071 | 0.0165 |

[All quality data](../data_quality_annual.csv) · [Flags](../data_quality_flags.csv) · [Weekday candidates](../data_quality_weekday_candidates.csv) · [PCA](../pca_variance.csv).
