# HMM fit and state diagnostics

Run: `run_20261030_080824_12346d` · source data: 2007-09-17–2026-10-22 · OOS returns: 2012-01-05–2026-10-22 · 10 bps one-way · cash 6.5% · extra execution delay 1 session(s).

Failed seeds are recorded in fits.csv; a fold with no acceptable fit aborts the run. No look-ahead fallback or forced occupancy balancing is used. State labels are volatility ranks within a fitted model, not stable identities across models or years. Identical exposure pairs are compared within each fit at tolerance 1e-6.

| model | signal_days | unique_daily_exposures_1e6 | fraction_near_full_exposure | mean_exposure | rejected_seed_fits |
| --- | --- | --- | --- | --- | --- |
| rv_2 | 3634 | 2383 | 0.0000 | 0.7311 | 0 |
| rv_3 | 3634 | 2307 | 0.0000 | 0.7866 | 0 |
| rvd_2 | 3634 | 1526 | 0.0000 | 0.7381 | 0 |
| rvd_3 | 3634 | 2018 | 0.0000 | 0.7591 | 0 |

[State pair allocation details](../state_allocation_diagnostics.csv) · [Occupancy](../model_occupancy.csv).
