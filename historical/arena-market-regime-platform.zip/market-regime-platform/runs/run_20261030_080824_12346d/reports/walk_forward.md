# Walk-forward validation

Run: `run_20261030_080824_12346d` · source data: 2007-09-17–2026-10-22 · OOS returns: 2012-01-05–2026-10-22 · 10 bps one-way · cash 6.5% · extra execution delay 1 session(s).

Annual refits train strictly before the first signal. Fold membership follows decision dates; return dates can extend across a calendar boundary because of execution delay. Fold drawdown is rebased within each fold, without artificial liquidation. Aggregate metrics below are recalculated from the complete OOS daily return series, **not** averages of fold ratios.

| strategy | observations | cagr | sharpe | sortino | max_drawdown | mean_exposure | turnover_per_year |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Buy & Hold | 3632 | 0.1145 | 0.3639 | 0.5015 | 0.3844 | 1.0000 | 0.0693 |
| Trend 50 | 3632 | 0.0926 | 0.2859 | 0.4037 | 0.2093 | 0.6836 | 12.8988 |
| Momentum 20 | 3632 | 0.0543 | -0.0484 | -0.0668 | 0.1763 | 0.6156 | 22.8850 |
| MA Reversion | 3632 | 0.0734 | 0.1275 | 0.1728 | 0.3471 | 0.2258 | 9.8475 |
| RSI Reversion | 3632 | 0.0616 | 0.0191 | 0.0256 | 0.3267 | 0.1875 | 6.9349 |
| Donchian | 3632 | 0.0525 | -0.0862 | -0.1172 | 0.1481 | 0.4950 | 6.9349 |
| Vol Target | 3632 | 0.0888 | 0.2456 | 0.3385 | 0.1976 | 0.8513 | 4.0087 |
| HMM Ensemble | 3632 | 0.0883 | 0.2544 | 0.3500 | 0.2101 | 0.7538 | 1.7689 |
| HMM + Trend | 3632 | 0.0912 | 0.2873 | 0.4012 | 0.1720 | 0.7187 | 7.3528 |

Full fold dates, costs and metrics: [fold_metrics.csv](../fold_metrics.csv).
