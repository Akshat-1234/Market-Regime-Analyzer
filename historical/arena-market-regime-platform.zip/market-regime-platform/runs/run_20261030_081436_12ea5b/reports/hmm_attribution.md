# HMM incremental-value attribution

Run: `run_20261030_081436_12ea5b` · source data: 2007-09-17–2026-10-22 · OOS returns: 2012-01-05–2026-10-22 · 10 bps one-way · cash 6.5% · extra execution delay 1 session(s).

Real HMM + Trend Sharpe 0.287 vs Trend 0.286; maximum drawdown 17.2% vs 20.9%. These are descriptive estimates, not proof of a true improvement.

## Controls

| control | n_simulations | cagr | sharpe | sharpe_p05 | sharpe_p95 | max_drawdown | mean_exposure | turnover_per_year | median_hmm_exposure_ks | fraction_real_sharpe_above_control |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Trend alone | 1 | 0.0926 | 0.2859 | 0.2859 | 0.2859 | 0.2093 | 0.6836 | 12.8988 | — | — |
| Trend + real HMM | 1 | 0.0912 | 0.2873 | 0.2873 | 0.2873 | 0.1720 | 0.7187 | 7.3528 | 0.0000 | — |
| Trend + Past-only shuffled | 200 | 0.0848 | 0.2262 | 0.1894 | 0.2634 | 0.2180 | 0.7178 | 13.8761 | 0.0136 | 0.9950 |
| Trend + Past-only block shuffled | 200 | 0.0927 | 0.2929 | 0.2767 | 0.3153 | 0.2207 | 0.7174 | 7.6439 | 0.0253 | 0.3100 |
| Trend + Exposure/turnover-matched random | 200 | 0.0931 | 0.2983 | 0.2620 | 0.3496 | 0.2142 | 0.7123 | 7.4214 | 0.0763 | 0.3650 |

Control p05/p95 are empirical simulation quantiles, **not** confidence intervals on market performance or p-values. The fraction real exceeds control is a descriptive fraction, not a formal significance test.

All controls only sample HMM exposures observed before each decision, using a 63-session rolling lookback. The rolling default was selected after inspecting preliminary full-history match diagnostics, not pre-registered; the previous full-history run is preserved for sensitivity. This adds selection risk. The first point initializes from the current real HMM; subsequent shuffled draws are prior-only resampling with replacement, block draws copy already completed historical blocks, and the matched random control uses a past-only redraw/hold rule. Therefore the distributions match only approximately. Exposure KS, percentiles and turnover differences are recorded per simulation. Shuffled paths can have substantially greater turnover; results include actual costs and a separately labelled approximate common-fee-schedule Sharpe diagnostic. The latter is a counterfactual, not a tradable backtest.

## Paired bootstrap vs trend and the mean of simulated controls

| control | observed_sharpe_difference | lower | upper | fraction_le_zero |
| --- | --- | --- | --- | --- |
| Trend | 0.0014 | -0.1887 | 0.1774 | 0.5090 |
| Mean control: Past-only shuffled | 0.0594 | -0.0186 | 0.1539 | 0.0930 |
| Mean control: Past-only block shuffled | -0.0074 | -0.0984 | 0.0943 | 0.6070 |
| Mean control: Exposure/turnover-matched random | -0.0148 | -0.0949 | 0.0772 | 0.6710 |

Each control reference here is the daily equal-weight mean return across its simulations; it is not a confidence interval against a single random control. Bootstrap fractions are not p-values. Intervals spanning zero do not prove equivalence. Block bootstrap assumes local stationarity and does not correct for the previous search across many configurations. Economic magnitude must be interpreted alongside turnover, exposure and costs.

## Market-period comparison

| period | control | real_sharpe | trend_sharpe | control_sharpe_median | fraction_real_above_control |
| --- | --- | --- | --- | --- | --- |
| 2013 | Past-only shuffled | -0.3772 | -0.4533 | -0.2840 | 0.0750 |
| 2013 | Past-only block shuffled | -0.3772 | -0.4533 | -0.2149 | 0.0000 |
| 2013 | Exposure/turnover-matched random | -0.3772 | -0.4533 | -0.2260 | 0.0050 |
| 2015–2016 | Past-only shuffled | -0.3956 | -0.1901 | -0.4130 | 0.6800 |
| 2015–2016 | Past-only block shuffled | -0.3956 | -0.1901 | -0.3372 | 0.0350 |
| 2015–2016 | Exposure/turnover-matched random | -0.3956 | -0.1901 | -0.3377 | 0.1100 |
| 2020 COVID + recovery | Past-only shuffled | 1.2809 | 1.8631 | 0.6249 | 1.0000 |
| 2020 COVID + recovery | Past-only block shuffled | 1.2809 | 1.8631 | 0.6923 | 1.0000 |
| 2020 COVID + recovery | Exposure/turnover-matched random | 1.2809 | 1.8631 | 0.7836 | 0.9600 |
| 2022 | Past-only shuffled | -0.5739 | -0.9353 | -0.6147 | 0.6450 |
| 2022 | Past-only block shuffled | -0.5739 | -0.9353 | -0.4872 | 0.1900 |
| 2022 | Exposure/turnover-matched random | -0.5739 | -0.9353 | -0.4858 | 0.2400 |

Short stress windows have noisy annualized ratios. [Simulation CSV](../attribution_simulations.csv) · [Distribution chart](../figures/attribution_sharpe.png).
