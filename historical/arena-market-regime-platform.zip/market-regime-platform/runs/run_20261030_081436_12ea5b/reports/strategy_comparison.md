# Strategy comparison

Run: `run_20261030_081436_12ea5b` · source data: 2007-09-17–2026-10-22 · OOS returns: 2012-01-05–2026-10-22 · 10 bps one-way · cash 6.5% · extra execution delay 1 session(s).

| strategy | cagr | sharpe | max_drawdown | calmar | mean_exposure | turnover_per_year |
| --- | --- | --- | --- | --- | --- | --- |
| Buy & Hold | 0.1145 | 0.3639 | 0.3844 | 0.2979 | 1.0000 | 0.0693 |
| Trend 50 | 0.0926 | 0.2859 | 0.2093 | 0.4425 | 0.6836 | 12.8988 |
| Momentum 20 | 0.0543 | -0.0484 | 0.1763 | 0.3080 | 0.6156 | 22.8850 |
| MA Reversion | 0.0734 | 0.1275 | 0.3471 | 0.2116 | 0.2258 | 9.8475 |
| RSI Reversion | 0.0616 | 0.0191 | 0.3267 | 0.1886 | 0.1875 | 6.9349 |
| Donchian | 0.0525 | -0.0862 | 0.1481 | 0.3548 | 0.4950 | 6.9349 |
| Vol Target | 0.0888 | 0.2456 | 0.1976 | 0.4494 | 0.8513 | 4.0087 |
| HMM Ensemble | 0.0883 | 0.2544 | 0.2101 | 0.4205 | 0.7538 | 1.7689 |
| HMM + Trend | 0.0912 | 0.2873 | 0.1720 | 0.5303 | 0.7187 | 7.3528 |

Full data: [performance.csv](../performance.csv). Costs include entries and daily fractional rebalancing; index price returns omit dividends and a real investable proxy would differ.
