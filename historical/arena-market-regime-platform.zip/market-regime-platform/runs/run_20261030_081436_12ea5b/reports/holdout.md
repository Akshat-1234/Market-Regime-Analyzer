# Holdout status

Run: `run_20261030_081436_12ea5b` · source data: 2007-09-17–2026-10-22 · OOS returns: 2012-01-05–2026-10-22 · 10 bps one-way · cash 6.5% · extra execution delay 1 session(s).

**Retrospective** 2023-01-02 00:00:00 through 2026-10-22 00:00:00 has already been examined, so it is NOT an untouched holdout. A prospective freeze was created only after this historical research. No post-freeze data are supplied; prospective evaluation is pending. Freeze manifest: [holdout_freeze.json](../holdout_freeze.json). Only decisions strictly after the freeze date and dataset boundary can qualify. Annual refits may use earlier data if the refit rule and parameters remain frozen.

| strategy | observations | cagr | sharpe | max_drawdown | turnover_per_year |
| --- | --- | --- | --- | --- | --- |
| Buy & Hold | 937 | 0.0626 | 0.0454 | 0.1577 | 0.0000 |
| Trend 50 | 937 | 0.0707 | 0.1038 | 0.1113 | 15.8599 |
| Momentum 20 | 937 | 0.0250 | -0.3988 | 0.1763 | 25.2681 |
| MA Reversion | 937 | 0.0920 | 0.3873 | 0.0983 | 8.8708 |
| RSI Reversion | 937 | 0.0260 | -0.4837 | 0.1051 | 6.1827 |
| Donchian | 937 | 0.0410 | -0.2535 | 0.1050 | 6.9890 |
| Vol Target | 937 | 0.0334 | -0.2073 | 0.1814 | 2.8744 |
| HMM Ensemble | 937 | 0.0378 | -0.1988 | 0.1553 | 1.7964 |
| HMM + Trend | 937 | 0.0547 | -0.0589 | 0.1213 | 8.8645 |
