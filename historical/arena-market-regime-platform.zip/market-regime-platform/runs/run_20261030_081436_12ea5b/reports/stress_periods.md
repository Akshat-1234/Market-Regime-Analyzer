# Stress-period analysis

Run: `run_20261030_081436_12ea5b` · source data: 2007-09-17–2026-10-22 · OOS returns: 2012-01-05–2026-10-22 · 10 bps one-way · cash 6.5% · extra execution delay 1 session(s).

Windows are fixed calendar years: 2013, 2015–2016, 2020 including COVID crash and recovery, and 2022. Returns are sliced from the original continuous portfolio (no extra entry or terminal sale). Recovery is the number of sessions from the window-local peak through recovery; if none occurs by the window end it is right-censored. Periods were not selected using this run’s winners.

| period | strategy | total_return | cagr | sharpe | max_drawdown | recovery_status | mean_exposure | turnover_per_year | return_difference_vs_buy_hold |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2013 | Buy & Hold | 0.0676 | 0.0690 | 0.1110 | 0.1458 | recovered_in_window | 1.0000 | 0.0000 | 0.0000 |
| 2013 | Trend 50 | -0.0058 | -0.0060 | -0.4533 | 0.1143 | not_recovered_by_window_end | 0.6356 | 24.4736 | -0.0734 |
| 2013 | HMM + Trend | 0.0129 | 0.0131 | -0.3772 | 0.0995 | not_recovered_by_window_end | 0.6481 | 13.0372 | -0.0547 |
| 2015–2016 | Buy & Hold | -0.0117 | -0.0061 | -0.3589 | 0.2252 | not_recovered_by_window_end | 1.0000 | 0.0000 | 0.0000 |
| 2015–2016 | Trend 50 | 0.0741 | 0.0376 | -0.1901 | 0.1249 | recovered_in_window | 0.5287 | 8.7746 | 0.0858 |
| 2015–2016 | HMM + Trend | 0.0356 | 0.0182 | -0.3956 | 0.1305 | recovered_in_window | 0.6181 | 5.3185 | 0.0473 |
| 2020 COVID + recovery | Buy & Hold | 0.1490 | 0.1503 | 0.4052 | 0.3844 | recovered_in_window | 1.0000 | 0.0000 | 0.0000 |
| 2020 COVID + recovery | Trend 50 | 0.3568 | 0.3601 | 1.8631 | 0.0747 | recovered_in_window | 0.7360 | 6.0450 | 0.2078 |
| 2020 COVID + recovery | HMM + Trend | 0.2460 | 0.2482 | 1.2809 | 0.1424 | recovered_in_window | 0.6995 | 4.6005 | 0.0970 |
| 2022 | Buy & Hold | 0.0433 | 0.0440 | -0.0284 | 0.1647 | recovered_in_window | 1.0000 | 0.0000 | 0.0000 |
| 2022 | Trend 50 | -0.0486 | -0.0494 | -0.9353 | 0.1439 | not_recovered_by_window_end | 0.5726 | 21.3275 | -0.0919 |
| 2022 | HMM + Trend | -0.0063 | -0.0064 | -0.5739 | 0.1337 | recovered_in_window | 0.6461 | 12.0249 | -0.0496 |

Full strategy table: [stress_periods.csv](../stress_periods.csv).
