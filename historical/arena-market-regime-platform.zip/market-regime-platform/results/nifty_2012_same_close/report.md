# Walk-forward regime backtest

Research only; not investment advice. This is a reconstruction, not an exact rerun of the unavailable earlier 14-model implementation.

## Data and setup

- Source: `csv`; path: `/home/user/market-regime-backtester/data/raw/nifty_index.csv`; SHA-256: `ea6dfffb93e5eabd8b6a2f96cd40d6b3ec5c7f47f2f9e6c0cbd3ca9a5f2ac5e4`.
- Source URL, if provided: not recorded.
- Data used: 2007-09-17 to 2026-10-22 (4684 rows).
- OOS signal dates: 2012-01-03 to 2026-10-22; realized return dates: 2012-01-04 to 2026-10-22 (3633 observations).
- Expanding training window, annual refits, at least 504 feature-valid days; rolling maximum: None.
- Primary model: `rvd_3`; 4 pre-specified model(s); state ordering is by **training weighted next-day volatility**.
- Target vol: 12.0%; HMM/trend blend: 50%/50%.
- Cash earns 6.50% annualized; 10 bps per one-way traded notional; 252 trading days/year.
- **Execution:** Same-close fill is assumed after observing that close; this is optimistic and may not be practically executable. Rerun with `--execution-delay 1` for a more conservative next-close sensitivity test.

## Input quality

`data_quality.csv` lists yearly close-return volatility and, if Open is available, its coverage, OHLC out-of-range observations, overnight/intraday volatility and the fraction of opens essentially equal to the previous close. These checks flag investigation candidates; they do not certify data quality. Early Open quotes can be unreliable. The default models use Close only.

## Performance

| Strategy | CAGR | Volatility | Sharpe | Sortino | Max DD | Calmar | Exposure | Turnover/yr |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Buy & Hold | 11.42% | 16.05% | 0.36 | 0.50 | 38.44% | 0.30 | 100.0% | 0.07 |
| Trend 50 | 9.55% | 10.96% | 0.31 | 0.44 | 20.12% | 0.47 | 68.3% | 12.90 |
| Momentum 20 | 9.04% | 10.19% | 0.28 | 0.40 | 14.98% | 0.60 | 61.5% | 22.88 |
| MA Reversion | 8.26% | 10.93% | 0.21 | 0.28 | 34.90% | 0.24 | 22.6% | 9.84 |
| RSI Reversion | 5.40% | 10.17% | -0.05 | -0.07 | 34.70% | 0.16 | 18.7% | 6.93 |
| Donchian | 6.09% | 8.81% | 0.00 | 0.00 | 15.49% | 0.39 | 49.5% | 6.93 |
| Vol Target | 8.74% | 11.76% | 0.24 | 0.33 | 19.54% | 0.45 | 85.1% | 3.98 |
| HMM Ensemble | 8.51% | 10.74% | 0.23 | 0.31 | 20.87% | 0.41 | 75.4% | 1.73 |
| HMM + Trend | 9.11% | 10.17% | 0.29 | 0.40 | 17.39% | 0.52 | 71.9% | 7.30 |

Max DD is a positive magnitude; turnover is one-way traded notional divided by portfolio value, annualized. Fractional targets rebalance daily and their turnover includes weight drift. Initial entry costs are included; no artificial terminal liquidation. Sharpe uses daily excess returns over the cash rate; CAGR is annualized by trading observations. Index price returns omit dividends unless the input is a total-return series.

![Equity and drawdowns](figures/equity_drawdown.png)

## H1 — descriptive regimes

Labels use the primary model's probability at each **decision close**; outcomes below are the market returns over the interval held after execution. Run lengths and occupancy describe the observed rank labels, not evidence that a distinct underlying economic regime exists. The effective number of occupied states is 2.12; the largest rank covers 56.0% of intervals. Ranks are recalibrated at every refit and can change meaning across years.

| Volatility rank | Days | Occupancy | Mean run | Held-interval mean | Held-interval vol/yr |
| --- | --- | --- | --- | --- | --- |
| 0 | 2035 | 56.0% | 59.9 | 0.037% | 12.5% |
| 1 | 1430 | 39.4% | 34.0 | 0.039% | 16.6% |
| 2 | 168 | 4.6% | 21.0 | 0.252% | 36.8% |

`train_transition_matrices.csv` contains the fitted matrices per refit; `empirical_transitions.csv` summarizes adjacent OOS rank labels, including boundaries between refits.

![Primary filtered probabilities](figures/regime_probabilities.png)

## H2 — conditional strategy results

See `regime_strategy_sharpe.csv` for post-cost Sharpe and sample size by decision-time regime. These are descriptive, conditional ex-post comparisons, not a significance test or an investable per-regime policy. The strategies have shared market exposure; small states can be highly unstable.

## H3 — paired Sharpe difference: HMM + Trend minus control

Circular moving-block percentile bootstrap, 20-day blocks, 95% intervals, seed 42. The same dates are sampled jointly for both strategies.

| Control | Observed Δ Sharpe | Block-bootstrap interval | Fraction Δ ≤ 0 | Samples |
| --- | --- | --- | --- | --- |
| Buy & Hold | -0.074 | [-0.334, +0.198] | 71.5% | 1000 |
| Trend 50 | -0.024 | [-0.235, +0.164] | 63.4% | 1000 |
| Vol Target | +0.053 | [-0.137, +0.241] | 27.4% | 1000 |

The fraction at or below zero is a bootstrap proportion, **not** a p-value. An interval containing zero does not prove equality or equivalence. Intervals do not correct for the many strategies tried in the previous conversation, hyperparameter choice, nonstationarity or data snooping.

## Important limitations

1. This rebuild uses a documented four-model volatility-target ensemble; the prior 14-model ensemble's code and configuration were not supplied. Do not compare these figures as an exact reproduction.
2. The prior discussion tested many variants and examined 2023–2026, so that period is not an untouched holdout. Freeze the design and evaluate on genuinely unseen data and other markets.
3. Yahoo or other index quotes can contain inaccurate historical OHLC, revisions, missing dates or corporate-action issues. Validate against the provider, and use an investable total-return proxy, realistic fees/taxes/slippage and an appropriate cash/funding rate.
4. A Gaussian HMM can overfit, has arbitrary labels, and filtered probabilities are model-dependent—not guarantees. Failed or poorly occupied fits are rejected; see `fits.csv`.
5. A drawdown reduction or historical Sharpe does not establish future alpha. No leverage, shorting, market impact, taxes, dividends, intraday execution or India VIX/FII features are modelled by default.
